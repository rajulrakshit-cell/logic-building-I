//
// Created by IIISI on 9/23/2025.
//

/*int main() {
    int a,n=0;
    printf("Enter your no");
    scanf("%d",&a);
    while (a>0) {
        a=a/10;
        n=n+1;
    }
    printf("Total digit is %d",n);
}*/
#include <stdio.h>
int main() {

}