#include <stdio.h>
int main() {
    int no;
    printf("Enter a number: ");
    scanf("%d",&no);
//  float f=(int)no;
    printf("The integer value is %d  \n",no);
    printf("The float value is %f  \n",no);

    return 0;
}