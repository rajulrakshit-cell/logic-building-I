//
// Created by IIISI on 9/24/2025.
//
/*
# include <stdio.h>
int main() {
    int n;
    printf("Enter a number:");
    scanf("%d",&n);

    printf(n>0?"positive \n ":"negative \n" );// ternary operator\

    n%2==0?printf("even"):printf("odd");


    return 0;


}*/
#include <stdio.h>
int main() {
    int n;
    printf("%d",n);
    return 0;
}