//
// Created by IIISI on 10/9/2025.
//
#include <stdio.h>
int main() {
    int i
}