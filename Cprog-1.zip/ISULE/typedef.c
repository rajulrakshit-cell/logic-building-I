#include <stdio.h>
struct point{
    int x ;
    int y ;

};
typedef struct point poiint;
