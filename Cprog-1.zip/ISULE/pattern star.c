//
// Created by IIISI on 10/7/2025.
//
/*#include <stdio.h>
int main( ) {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = 1; i <= rows; i++) {
        for (int j=1; j<=i; j++) {
            printf("*");
        }
        printf("\n");
    }

    return 0;

}
#include <stdio.h>
int main( ) {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = 1; i <= rows; i++) {
        for (int j=1; j<=i; j++) {
            printf("%d",j);
        }
        printf("\n");
    }

    return 0;
}

#include <stdio.h>
int main( ) {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = 1; i <= rows; i++) {
        for (int j=1; j<=i; j++) {
            printf("A");
        }
        printf("\n");
    }

    return 0;
}

#include <stdio.h>
int main( ) {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = 1; i <= rows; i++) {
        int ascii=65;
        for (int j=1; j<=i; j++) {
            printf("%c ", ascii);
            ascii++;
        }
        printf("\n");
    }

    return 0;
}
#include <stdio.h>
int main( ) {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    int ascii=65;
    for (int i = 1; i <= rows; i++) {
        for (int j=1; j<=i; j++) {
            printf("%c ", ascii);
            ascii++;
        }
        printf("\n");
    }

    return 0;
}

#include <stdio.h>
int main( ) {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = rows ; i >0; i--) {
        for (int j=0; j<i; j++) {
            printf("*");

        }
        printf("\n");
    }

    return 0;
}*/
/*
#include <stdio.h>

int main( ) {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = 1; i <= rows; i++ ) {
        for (int j = i; j <= rows; j++ ) {
            printf(" ");

        }
        for (int n = 1; n <=i; n++ ) {
            printf("*");
        }
        printf("\n");
    }
    return 0;

        }

#include <stdio.h>
int main () {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = 1; i <= rows; i++ ) {
        for (int j = i; j <= rows; j++ ) {
            printf(" ");

        }
        for (int n = 1; n <=i; n++ ) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;


}*/
/*
#include <stdio.h>
int main () {
    int rows;
    printf("enter the number of rows:");
    scanf("%d",&rows);
    for (int i = 0; i <= rows; i++ ) {
        for (int j = 0; j <=i; j++ ) {
            printf("*");
        }
        printf("\n");
    }
    for (int i = 1; i <= rows; i++ ) {
        for (int j = i; j <= rows; j++ ) {
            printf("*");
        }
        printf("\n");

    }


}*/
