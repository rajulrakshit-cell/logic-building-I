//
// Created by IIISI on 9/30/2025.
//
#include <stdio.h>
int main() {
    int a=1;

    while(a!=101) {
        printf("Hello World %d  \n",a);
        a++;
    }
    return 0;
}